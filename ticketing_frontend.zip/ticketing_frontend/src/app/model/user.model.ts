export interface User{
    password: string;
    username: string;
}
