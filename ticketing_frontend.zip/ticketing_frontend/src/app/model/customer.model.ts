export interface Customer{
    customerName: string;
    customerContact: string;
    customerPriority: boolean;
    customerPassword: string;
    customerEmail: string;
}