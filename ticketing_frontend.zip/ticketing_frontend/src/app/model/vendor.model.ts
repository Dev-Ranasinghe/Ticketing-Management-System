export interface Vendor{
    vendorName: string;
    vendorContact: string;
    vendorPassword: string;
    vendorEmail: string;
    vendorId: number;
}