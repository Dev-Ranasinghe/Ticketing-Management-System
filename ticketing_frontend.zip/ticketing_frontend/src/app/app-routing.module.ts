import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { VendorDashboardComponent } from './vendor-dashboard/vendor-dashboard.component';
import { EventCreateComponent } from './event-create/event-create.component';

const routes: Routes = [{ path: '', redirectTo: '/login', pathMatch: 'full' }, // Redirect to login by default
                        { path: 'login', component: LoginComponent },
                        { path: 'vendor-dashboard', component: VendorDashboardComponent },
                        { path: 'event-create', component: EventCreateComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
